"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var VBGBox = (function () {
    function VBGBox() {
    }
    return VBGBox;
}());
var VBGZone = (function (_super) {
    __extends(VBGZone, _super);
    function VBGZone() {
        _super.apply(this, arguments);
    }
    return VBGZone;
}(VBGBox));
var VBGVideo = (function (_super) {
    __extends(VBGVideo, _super);
    function VBGVideo() {
        _super.apply(this, arguments);
    }
    return VBGVideo;
}(VBGZone));
var VBGInner = (function (_super) {
    __extends(VBGInner, _super);
    function VBGInner() {
        _super.call(this);
        this.width = window.innerWidth;
        this.height = window.innerHeight;
    }
    VBGInner.prototype.ratio = function () {
        return this.width / this.height;
    };
    return VBGInner;
}(VBGBox));
var VideoBackgroundComponent = (function () {
    function VideoBackgroundComponent() {
        this.video = new VBGVideo;
        this.main = new VBGZone;
        this.min = new VBGBox;
    }
    //Implements
    VideoBackgroundComponent.prototype.ngOnInit = function () {
        this.min.width = this.minWidth;
        this.min.height = this.minHeight;
        this.calc_resize();
    };
    //DOM events
    VideoBackgroundComponent.prototype.onResize = function () {
        this.calc_resize();
    };
    //Private functions
    VideoBackgroundComponent.prototype.calc_resize = function () {
        var inner = new VBGInner;
        if (inner.ratio() > 1280 / 720) {
            if (inner.width < this.min.width) {
                this.video.width = this.min.width;
                this.video.top = Math.round((inner.height - this.min.width * 720 / 1280) / 2);
            }
            else {
                this.video.width = inner.width;
                this.video.top = Math.round((inner.height - inner.width * 720 / 1280) / 2);
            }
            this.video.height = null;
            this.video.left = 0;
        }
        else {
            if (inner.height < this.min.height) {
                this.video.height = this.minHeight;
                this.video.left = Math.round((inner.width - this.min.height * 1280 / 720) / 2);
            }
            else {
                this.video.height = inner.height;
                this.video.left = Math.round((inner.width - inner.height * 1280 / 720) / 2);
            }
            this.video.width = null;
            this.video.top = 0;
        }
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Boolean)
    ], VideoBackgroundComponent.prototype, "sound", void 0);
    __decorate([
        core_1.Input('min-height'), 
        __metadata('design:type', Number)
    ], VideoBackgroundComponent.prototype, "minHeight", void 0);
    __decorate([
        core_1.Input('min-width'), 
        __metadata('design:type', Number)
    ], VideoBackgroundComponent.prototype, "minWidth", void 0);
    VideoBackgroundComponent = __decorate([
        core_1.Component({
            selector: 'video-background',
            template: '<div (window:resize)="onResize()" [style.min-width]="min.width+\'px\'" [style.min-height]="min.height+\'px\'" style="width:100vw; height:100vh;display:block;z-index:-1;position: absolute;overflow: hidden;">' +
                '<video [muted]="!video.sound" [style.top]="video.top" [style.left]="video.left" [style.width]="video.width" [style.height]="video.height" style="position:relative;" autoplay loop preload ><ng-content></ng-content></video>' +
                '</div>'
        }), 
        __metadata('design:paramtypes', [])
    ], VideoBackgroundComponent);
    return VideoBackgroundComponent;
}());
exports.VideoBackgroundComponent = VideoBackgroundComponent;
//# sourceMappingURL=videobackground.component.js.map