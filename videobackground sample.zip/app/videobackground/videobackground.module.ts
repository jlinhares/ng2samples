import { NgModule }      from '@angular/core';
import {VideoBackgroundComponent} from './videobackground.component';

@NgModule({
  exports:[VideoBackgroundComponent],
  declarations: [ VideoBackgroundComponent ]
})
export class VideoBackgroundModule { 

}
