import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {VideoBackgroundModule} from './videobackground/videobackground.module'
import { AppComponent }   from './app.component';

@NgModule({
  imports:      [ BrowserModule, VideoBackgroundModule ],
  declarations: [ AppComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }