This zip file contains the files to execute the sample

Requires Node v5.x.x or higher and npm 3.x.x or higher.

First, get the needed node modules by running

	> npm install

then, to run the sample just execute

	> npm start